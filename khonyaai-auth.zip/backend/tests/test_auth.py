import secrets
from datetime import timedelta

import pytest
from fastapi import HTTPException
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient

from app import mock_db
from app.auth import (
    _check_mock_otp,
    bind_registration_proof,
    get_current_user,
    registration_proofs,
)
from app.main import app

client = TestClient(app)


def _registration_proof_for(user):
    proof = secrets.token_urlsafe(32)
    bind_registration_proof(proof, user["id"])
    return proof


def test_AC_02_02_auth_endpoint_methods_and_paths_registered():
    # รองรับ REQ-FN-202 และตรวจ AC-02-02 โดยไม่เรียก handler
    auth_routes = {
        (method, route.path)
        for route in app.routes
        if isinstance(route, APIRoute) and route.path.startswith("/api/auth/")
        and "auth" in (route.tags or [])
        for method in route.methods or ()
    }

    assert auth_routes == {
        ("POST", "/api/auth/login"),
        ("POST", "/api/auth/otp-challenges"),
        ("POST", "/api/auth/otp-challenges/{otp_challenge_id}/resend"),
        ("POST", "/api/auth/verify-otp"),
        ("GET", "/api/auth/me"),
    }


def test_AC_02_01_verified_account_login_issues_token():
    # ตรวจ AC-02-01: บัญชี verified login แล้วได้ token โดยไม่เริ่ม OTP
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_tokens = mock_db.tokens.copy()
    original_challenges = mock_db.otp_challenges.copy()
    user["is_verified"] = True

    try:
        response = client.post(
            "/api/auth/login",
            json={"email": user["email"], "password": user["password"]},
        )

        assert response.status_code == 200
        body = response.json()
        assert set(body) == {"token"}
        assert body["token"] not in original_tokens
        assert mock_db.tokens[body["token"]] == user["id"]
        assert mock_db.otp_challenges == original_challenges
    finally:
        user["is_verified"] = original_verified
        mock_db.tokens.clear()
        mock_db.tokens.update(original_tokens)
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)


def test_AC_02_01_unverified_account_login_requires_verification():
    # ตรวจ AC-02-01: บัญชี unverified ปฏิเสธ login และไม่เริ่ม OTP
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_tokens = mock_db.tokens.copy()
    original_challenges = mock_db.otp_challenges.copy()
    original_proofs = registration_proofs.copy()
    user["is_verified"] = False

    try:
        response = client.post(
            "/api/auth/login",
            json={"email": user["email"], "password": user["password"]},
        )

        assert response.status_code == 403
        assert response.json() == {"detail": "Account verification required"}
        assert mock_db.tokens == original_tokens
        assert mock_db.otp_challenges == original_challenges
    finally:
        user["is_verified"] = original_verified
        mock_db.tokens.clear()
        mock_db.tokens.update(original_tokens)
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)
        registration_proofs.clear()
        registration_proofs.update(original_proofs)


def test_AC_02_01_login_rejects_invalid_credentials_and_request():
    # ตรวจ contract login: credential ผิดและ request ไม่ถูกต้อง
    invalid_credentials = client.post(
        "/api/auth/login",
        json={"email": "test@mail.com", "password": "wrong"},
    )
    invalid_request = client.post(
        "/api/auth/login",
        json={"email": "not-an-email", "password": ""},
    )

    assert invalid_credentials.status_code == 401
    assert invalid_credentials.json() == {"detail": "Invalid email or password"}
    assert invalid_request.status_code == 422
    assert invalid_request.json() == {"detail": "Request validation failed"}


def test_AC_02_01_registration_proof_starts_otp_once():
    # ตรวจ AC-02-01: proof ที่ผูกกับบัญชีใช้เริ่ม OTP ได้ครั้งเดียว
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_challenges = mock_db.otp_challenges.copy()
    original_proofs = registration_proofs.copy()
    user["is_verified"] = False

    try:
        proof = _registration_proof_for(user)
        response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": proof},
        )
        replay = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": proof},
        )
        invalid_proof = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": "unknown-proof"},
        )
        invalid_request = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": ""},
        )

        assert response.status_code == 200
        assert set(response.json()) == {"otp_challenge_id", "mock_otp"}
        challenge = mock_db.otp_challenges[response.json()["otp_challenge_id"]]
        assert challenge["user_id"] == user["id"]
        assert challenge["phone"] == user["phone"]
        assert replay.status_code == invalid_proof.status_code == 400
        assert replay.json() == invalid_proof.json() == {
            "detail": "Invalid registration proof"
        }
        assert invalid_request.status_code == 422
        assert invalid_request.json() == {
            "detail": "Request validation failed"
        }
    finally:
        user["is_verified"] = original_verified
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)
        registration_proofs.clear()
        registration_proofs.update(original_proofs)


def test_AC_02_06_otp_lifetime_attempts_and_resend():
    # ตรวจ AC-02-06: อายุ OTP, การขอใหม่, attempts แยกชุด และ status/error
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_tokens = mock_db.tokens.copy()
    original_challenges = mock_db.otp_challenges.copy()
    original_proofs = registration_proofs.copy()
    user["is_verified"] = False

    try:
        first_response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": _registration_proof_for(user)},
        )
        second_response = client.post(
            f"/api/auth/otp-challenges/{first_response.json()['otp_challenge_id']}/resend",
        )
        first_id = first_response.json()["otp_challenge_id"]
        second_id = second_response.json()["otp_challenge_id"]
        first_challenge = mock_db.otp_challenges[first_id]
        second_challenge = mock_db.otp_challenges[second_id]

        assert first_response.status_code == second_response.status_code == 200
        assert first_id != second_id
        assert first_challenge["status"] == "active"
        assert second_challenge["status"] == "active"
        assert first_challenge["created_at"] <= second_challenge["created_at"]

        accepted_previous_challenge = _check_mock_otp(first_id, mock_db.MOCK_OTP)
        assert accepted_previous_challenge["status"] == "verified"

        for expected_attempts in (1, 2, 3):
            with pytest.raises(HTTPException) as error:
                _check_mock_otp(second_id, "000000")

            assert error.value.status_code == 400
            assert error.value.detail == "OTP verification failed"
            assert second_challenge["failed_attempts"] == expected_attempts
        assert second_challenge["status"] == "locked"

        with pytest.raises(HTTPException) as locked_error:
            _check_mock_otp(second_id, mock_db.MOCK_OTP)
        assert locked_error.value.status_code == 400
        assert second_challenge["failed_attempts"] == 3

        third_response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": _registration_proof_for(user)},
        )
        third_id = third_response.json()["otp_challenge_id"]
        third_challenge = mock_db.otp_challenges[third_id]
        third_challenge["created_at"] -= timedelta(minutes=15)
        with pytest.raises(HTTPException) as expired_error:
            _check_mock_otp(third_id, mock_db.MOCK_OTP)
        assert expired_error.value.status_code == 400
        assert expired_error.value.detail == "OTP verification failed"
        assert third_challenge["status"] == "expired"

        with pytest.raises(HTTPException) as unknown_error:
            _check_mock_otp("unknown-challenge", mock_db.MOCK_OTP)
        assert unknown_error.value.status_code == 400
        assert unknown_error.value.detail == "OTP verification failed"
    finally:
        user["is_verified"] = original_verified
        mock_db.tokens.clear()
        mock_db.tokens.update(original_tokens)
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)
        registration_proofs.clear()
        registration_proofs.update(original_proofs)


def test_AC_02_03_verified_otp_marks_account_without_issuing_token():
    # ตรวจ AC-02-03: ยืนยัน OTP โดยไม่มี token ก่อน และไม่ออก token
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_tokens = mock_db.tokens.copy()
    original_challenges = mock_db.otp_challenges.copy()
    original_proofs = registration_proofs.copy()
    user["is_verified"] = False

    try:
        challenge_response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": _registration_proof_for(user)},
        )
        second_challenge_response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": _registration_proof_for(user)},
        )
        challenge_id = challenge_response.json()["otp_challenge_id"]
        second_challenge_id = second_challenge_response.json()["otp_challenge_id"]
        assert challenge_response.status_code == 200
        assert second_challenge_response.status_code == 200
        assert challenge_id in mock_db.otp_challenges
        assert mock_db.tokens == original_tokens

        response = client.post(
            "/api/auth/verify-otp",
            json={
                "otp_challenge_id": challenge_id,
                "otp": mock_db.MOCK_OTP,
            },
        )

        assert response.status_code == 200
        assert response.json() == {"is_verified": True}
        assert user["is_verified"] is True
        assert mock_db.tokens == original_tokens
        assert mock_db.otp_challenges[challenge_id]["status"] == "verified"

        repeated_verification = client.post(
            "/api/auth/verify-otp",
            json={
                "otp_challenge_id": second_challenge_id,
                "otp": mock_db.MOCK_OTP,
            },
        )
        assert repeated_verification.status_code == 400
        assert repeated_verification.json() == {
            "detail": "OTP verification failed"
        }

        invalid_request = client.post(
            "/api/auth/verify-otp",
            json={"otp_challenge_id": challenge_id, "otp": "１２３４５６"},
        )
        assert invalid_request.status_code == 422
        assert invalid_request.json() == {
            "detail": "Request validation failed"
        }
    finally:
        user["is_verified"] = original_verified
        mock_db.tokens.clear()
        mock_db.tokens.update(original_tokens)
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)
        registration_proofs.clear()
        registration_proofs.update(original_proofs)


def test_AC_02_04_token_identifies_current_user():
    # ตรวจ AC-02-04: token จาก flow สำเร็จระบุผู้จองผ่าน helper เดิมและ Feature 003
    user = mock_db.users[0]
    original_verified = user["is_verified"]
    original_tokens = mock_db.tokens.copy()
    original_challenges = mock_db.otp_challenges.copy()
    original_proofs = registration_proofs.copy()
    original_bookings = mock_db.bookings.copy()
    original_status_logs = mock_db.status_logs.copy()
    user["is_verified"] = False

    try:
        challenge_response = client.post(
            "/api/auth/otp-challenges",
            json={"registration_proof": _registration_proof_for(user)},
        )
        assert challenge_response.status_code == 200
        challenge_id = challenge_response.json()["otp_challenge_id"]

        verify_response = client.post(
            "/api/auth/verify-otp",
            json={
                "otp_challenge_id": challenge_id,
                "otp": mock_db.MOCK_OTP,
            },
        )
        assert verify_response.status_code == 200
        assert verify_response.json() == {"is_verified": True}
        assert mock_db.tokens == original_tokens

        login_response = client.post(
            "/api/auth/login",
            json={"email": user["email"], "password": user["password"]},
        )
        assert login_response.status_code == 200
        token = login_response.json()["token"]

        assert mock_db.tokens[token] == user["id"]
        assert get_current_user(f"Bearer {token}") is user

        consumer_response = client.post(
            "/api/dev/seed-booking",
            json={"distance_km": 5},
            headers={"Authorization": f"Bearer {token}"},
        )

        assert consumer_response.status_code == 201
        assert consumer_response.json()["user_id"] == user["id"]
        assert mock_db.tokens[token] == user["id"]
    finally:
        user["is_verified"] = original_verified
        mock_db.tokens.clear()
        mock_db.tokens.update(original_tokens)
        mock_db.otp_challenges.clear()
        mock_db.otp_challenges.update(original_challenges)
        registration_proofs.clear()
        registration_proofs.update(original_proofs)
        mock_db.bookings[:] = original_bookings
        mock_db.status_logs[:] = original_status_logs


def test_AC_02_02_me_returns_only_confirmed_user_fields():
    # ตรวจ AC-02-02: /me ใช้ Bearer token และคืนเฉพาะ fields ที่ยืนยัน
    user = mock_db.users[0]
    token = next(
        token
        for token, user_id in mock_db.tokens.items()
        if user_id == user["id"]
    )

    response = client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "id": user["id"],
        "name": user["name"],
        "email": user["email"],
    }


def test_AC_02_02_me_requires_a_valid_bearer_token():
    # ตรวจ AC-02-02: /me ปฏิเสธคำขอที่ไม่มี token หรือมี token ใช้ไม่ได้
    missing_token = client.get("/api/auth/me")
    invalid_token = client.get(
        "/api/auth/me",
        headers={"Authorization": "Bearer invalid-token"},
    )

    assert missing_token.status_code == 401
    assert missing_token.json() == {"detail": "Authentication required"}
    assert invalid_token.status_code == 401
    assert invalid_token.json() == {"detail": "Authentication required"}
